# Quiz Master Pro Android project

## Open in VS Code
1. Extract this ZIP.
2. In VS Code choose File > Open Folder.
3. Select the `QuizMaster-Android` folder. It must contain `settings.gradle`, `build.gradle`, and `app/`.

## Requirements for local APK build
- JDK 17
- Android SDK Platform 35 and Build Tools 35.0.0
- Gradle 8.9
- VS Code Java extensions are optional; VS Code itself does not include the Android SDK or Gradle.

## Build from terminal
From the `QuizMaster-Android` folder, run:

```bash
gradle --version
gradle --no-daemon :app:assembleDebug
```

The APK is created at:
`app/build/outputs/apk/debug/app-debug.apk`

## Build with GitHub Actions
1. Upload the complete `QuizMaster-Android` folder to the root of your GitHub repository.
2. Preserve `.github/workflows/build-apk.yml` in the repository.
3. Commit and push to the `main` branch, or use Actions > Build Quiz Master Pro APK > Run workflow.
4. Download the artifact `Quiz-Master-Pro-v1.2-APK`.

## Voice command setup on Android
- Grant microphone permission when prompted.
- Ensure a speech recognition service is enabled (Google Speech Services / Google voice typing).
- Internet may be required. Recognition locale is English (India).
- Tap Speak, wait for Listening, then say one short supported command.

Package ID: `com.quizmaster.app`
App version: `1.2`
