QUIZ MASTER PRO v1.4 - NATIVE ANDROID TEXT-TO-SPEECH FIX

This version fixes spoken quiz narration by using Android's native TextToSpeech engine.
The previous version depended on window.speechSynthesis inside a local-file Android WebView,
which is not consistently implemented by Android System WebView. The microphone voice-command
feature uses Android SpeechRecognizer and is separate from spoken narration.

SPOKEN EXPERIENCE
- When Start is pressed, the app speaks the game instructions and how scoring works.
- After a wheel spin, the app announces the category, then reads the question and choices A-D.
- When an answer is selected, the app immediately interrupts any remaining question narration
  and announces whether it is correct, awards ten points when correct, and reads the explanation.
- Repeat Question reads the question and all four choices again.
- Voice On/Off controls native speech output.

ANDROID REQUIREMENTS
- Android 6.0 or later (minSdk 23).
- Android Text-to-Speech engine installed and enabled. Google Speech Services / Speech Services
  by Google is recommended, with English (India) voice data installed.
- If speech is silent, open Android Settings > Accessibility or General management > Text-to-speech
  output (wording varies by device), choose a speech engine, and install English voice data.
- Voice commands additionally require microphone permission and an available speech-recognition
  provider; network may be needed for English (India) recognition.

BUILD
Use GitHub Actions workflow at .github/workflows/build-apk.yml. The workflow expects the project
ZIP Quiz-Master-Pro-v1.4-TTS-FIX.zip in the repository root, extracts it, locates settings.gradle,
and builds app-debug.apk.

NOTE
The source project has been syntax/structure checked, but the APK must still be compiled by GitHub
Actions and tested on the target Android phone. Native TTS is much more reliable than Web Speech
synthesis in Android WebView, but actual voice availability depends on the phone's installed TTS
engine and voice data.
