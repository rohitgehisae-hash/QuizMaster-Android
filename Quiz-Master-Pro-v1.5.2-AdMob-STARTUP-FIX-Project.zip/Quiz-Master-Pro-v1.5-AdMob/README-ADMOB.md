# Quiz Master Pro v1.5 – AdMob Edition

This is the compact Android WebView quiz app with native Android Text-to-Speech,
speech recognition, and a bottom anchored adaptive AdMob banner.

## AdMob identifiers supplied by the app owner
- AdMob App ID: `ca-app-pub-4092383876985189~7511148642`
- Production banner ad unit: `ca-app-pub-4092383876985189/5793249008`

## Safe ad build variants
- `debug`: uses Google's official test banner unit `ca-app-pub-3940256099942544/9214589741`.
- `release`: uses the owner's production banner unit above.

Always install/test the debug APK first. Do not click ads during testing. The release APK
must be signed with the app owner's private release keystore before distribution.

## Child-directed app safeguards
The quiz is intended for young learners. The app sets GMA Next-Gen SDK
`AgeRestrictedTreatment.CHILD` and disables SDK coarse-location collection. Review
AdMob and Google Play Families requirements, declare the correct target audience,
content rating, data safety disclosures, and privacy policy before public distribution.
Set the maximum ad content rating to G in AdMob settings. Confirm that all ads and
advertising practices comply with applicable child-directed advertising rules.

## Build
From the project root:
```bash
gradle --no-daemon :app:assembleDebug
```
Debug APK:
`app/build/outputs/apk/debug/app-debug.apk`

Release APK (unsigned unless you configure signing):
`app/build/outputs/apk/release/app-release-unsigned.apk`

## SDK
Google Mobile Ads (GMA) Next-Gen SDK 1.7.0, as documented by Google at:
https://developers.google.com/admob/android/next-gen/quick-start
Banner guide:
https://developers.google.com/admob/android/next-gen/banner


Build fix v1.5.1: uses the Next-Gen SDK MaxAdContentRating constant rather than a String literal.


## v1.5.2 startup and installation fixes
- RequestConfiguration is now passed into InitializationConfig.Builder before MobileAds.initialize,
  following Google's GMA Next-Gen targeting instructions. This prevents calling setRequestConfiguration
  before the SDK is initialized.
- Release variant is signed with the Gradle debug signing key for direct sideload testing only.
  It is NOT a Play Store production signing configuration. Configure your private upload key before
  Play Store publication.
- versionCode 8 / versionName 1.5.2.
