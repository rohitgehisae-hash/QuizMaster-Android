package com.quizmaster.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
import android.view.View;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.util.Log;
import android.util.DisplayMetrics;
import android.content.res.Configuration;
import androidx.annotation.NonNull;
import com.google.android.libraries.ads.mobile.sdk.MobileAds;
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig;
import com.google.android.libraries.ads.mobile.sdk.banner.AdView;
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize;
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd;
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest;
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback;
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError;
import com.google.android.libraries.ads.mobile.sdk.common.AgeRestrictedTreatment;
import com.google.android.libraries.ads.mobile.sdk.common.RequestConfiguration;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 701;
    private WebView webView;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private boolean waitingForPermission = false;
    private String pendingSpeech = null;

    private LinearLayout rootLayout;
    private LinearLayout adSlot;
    private AdView adView;
    private boolean adsInitialized = false;
    private static final String ADMOB_APP_ID = "ca-app-pub-4092383876985189~7511148642";
    private static final String TAG = "QuizMasterAdMob";

    private class VoiceBridge {
        @JavascriptInterface public void startListening() { runOnUiThread(() -> beginVoiceRecognition()); }
    }

    private class SpeechBridge {
        @JavascriptInterface public void speak(String text) {
            if (text == null) return;
            runOnUiThread(() -> speakNative(text));
        }
        @JavascriptInterface public void speakNow(String text) {
            if (text == null) return;
            runOnUiThread(() -> speakNative(text, true));
        }
        @JavascriptInterface public void stop() {
            runOnUiThread(() -> { if (textToSpeech != null) textToSpeech.stop(); pendingSpeech = null; });
        }
        @JavascriptInterface public boolean isReady() { return ttsReady; }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(new Locale("en", "IN"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    result = textToSpeech.setLanguage(Locale.US);
                }
                textToSpeech.setSpeechRate(0.92f);
                textToSpeech.setPitch(1.04f);
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
                if (ttsReady && pendingSpeech != null) {
                    String queued = pendingSpeech; pendingSpeech = null; speakNative(queued);
                }
                sendTtsStatus(ttsReady ? "ready" : "language-unavailable");
            } else {
                ttsReady = false;
                sendTtsStatus("initialization-failed");
            }
        });

        // Main app layout: quiz WebView fills available space; AdMob banner stays anchored at bottom.
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        webView.addJavascriptInterface(new SpeechBridge(), "AndroidTTS");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        rootLayout.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        adSlot = new LinearLayout(this);
        adSlot.setOrientation(LinearLayout.VERTICAL);
        adSlot.setGravity(Gravity.CENTER);
        adSlot.setBackgroundColor(Color.WHITE);
        adSlot.setVisibility(View.GONE);
        TextView adLabel = new TextView(this);
        adLabel.setText("ADVERTISEMENT");
        adLabel.setTextSize(9);
        adLabel.setTextColor(Color.rgb(105, 112, 125));
        adLabel.setGravity(Gravity.CENTER);
        adLabel.setPadding(0, dp(2), 0, dp(1));
        adSlot.addView(adLabel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(13)));
        rootLayout.addView(adSlot, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(rootLayout);
        webView.loadUrl("file:///android_asset/index.html");
        initializeAdMob();
    }


    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void initializeAdMob() {
        // This quiz is designed for young children. Apply child age treatment and disable
        // coarse-location collection before initializing the Google Mobile Ads Next-Gen SDK.
        RequestConfiguration requestConfiguration =
                new RequestConfiguration.Builder()
                        .setAgeRestrictedTreatment(AgeRestrictedTreatment.CHILD)
                        .setMaxAdContentRating(RequestConfiguration.MaxAdContentRating.MAX_AD_CONTENT_RATING_G)
                        .setCoarseLocationCollectionEnabled(false)
                        .build();
        new Thread(() -> {
            try {
                InitializationConfig config =
                        new InitializationConfig.Builder(ADMOB_APP_ID)
                                .setRequestConfiguration(requestConfiguration)
                                .build();
                MobileAds.initialize(this, config, initializationStatus -> {
                    adsInitialized = true;
                    runOnUiThread(this::loadBottomBanner);
                });
            } catch (Exception e) {
                Log.e(TAG, "AdMob initialization failed", e);
            }
        }, "AdMob-Init").start();
    }

    private void loadBottomBanner() {
        if (isFinishing() || isDestroyed() || adSlot == null) return;

        try {
            int screenWidthDp = (int) (getResources().getDisplayMetrics().widthPixels /
                    getResources().getDisplayMetrics().density);
            AdSize adSize = AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, screenWidthDp);

            adView = new AdView(this);
            FrameLayout bannerFrame = new FrameLayout(this);
            bannerFrame.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            bannerFrame.addView(adView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER));

            adSlot.addView(bannerFrame, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

            BannerAdRequest request =
                    new BannerAdRequest.Builder(BuildConfig.ADMOB_BANNER_ID, adSize).build();

            adView.loadAd(request, new AdLoadCallback<BannerAd>() {
                @Override
                public void onAdLoaded(@NonNull BannerAd bannerAd) {
                    Log.i(TAG, "AdMob banner loaded successfully.");
                    runOnUiThread(() -> {
                        if (adSlot != null) adSlot.setVisibility(View.VISIBLE);
                    });
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                    Log.w(TAG, "AdMob banner failed to load: " + adError);
                    runOnUiThread(() -> {
                        if (adSlot != null) adSlot.setVisibility(View.GONE);
                    });
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Unable to create AdMob banner", e);
            if (adSlot != null) adSlot.setVisibility(View.GONE);
        }
    }

    private void speakNative(String text) { speakNative(text, false); }

    private void speakNative(String text, boolean interrupt) {
        if (textToSpeech == null) return;
        String clean = text.replaceAll("_{2,}", " ").replaceAll("(?i)\\[\\s*blank\\s*\\]", " ").replaceAll("\\s+", " ").trim();
        if (clean.isEmpty()) return;
        if (!ttsReady) { pendingSpeech = clean; return; }
        textToSpeech.speak(clean, interrupt ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, "quiz-" + UUID.randomUUID());
    }

    private void sendTtsStatus(String status) {
        if (webView == null) return;
        String safe = JSONObject.quote(status);
        webView.post(() -> webView.evaluateJavascript("window.onNativeTTSStatus && window.onNativeTTSStatus(" + safe + ")", null));
    }

    private void beginVoiceRecognition() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            waitingForPermission = true;
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendVoiceError("No speech recognition service is available. Install or enable Google voice input.");
            return;
        }
        try {
            if (speechRecognizer != null) { try { speechRecognizer.cancel(); } catch (Exception ignored) {} speechRecognizer.destroy(); speechRecognizer = null; }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { sendVoiceStatus("Listening… speak now."); }
                @Override public void onBeginningOfSpeech() { sendVoiceStatus("I can hear you…"); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) { sendVoiceError(errorMessage(error)); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) sendVoiceResult(matches.get(0));
                    else sendVoiceError("I didn't catch that. Please try again.");
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN");
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            sendVoiceError("Unable to start microphone. Check your voice input service.");
        }
    }

    private String errorMessage(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "Microphone audio error. Try again.";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Microphone permission is required.";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Voice recognition needs an internet connection.";
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "I didn't catch that. Please speak clearly and try again.";
            default: return "Voice recognition failed. Please try again.";
        }
    }
    private void sendVoiceStatus(String message) { sendJs("window.onNativeVoiceStatus", message); }
    private void sendVoiceResult(String result) { sendJs("window.onNativeVoiceResult", result); }
    private void sendVoiceError(String message) { sendJs("window.onNativeVoiceError", message); }
    private void sendJs(String callback, String message) {
        if (webView == null) return;
        String safe = JSONObject.quote(message);
        webView.post(() -> webView.evaluateJavascript(callback + " && " + callback + "(" + safe + ")", null));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && waitingForPermission) beginVoiceRecognition();
            else sendVoiceError("Please allow microphone access to use voice commands.");
            waitingForPermission = false;
        }
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() {
        if (speechRecognizer != null) { try { speechRecognizer.cancel(); } catch (Exception ignored) {} speechRecognizer.destroy(); speechRecognizer = null; }
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; }
        if (adView != null) {
            try { adView.destroy(); } catch (Exception ignored) {}
            adView = null;
        }
        if (webView != null) { webView.removeJavascriptInterface("AndroidVoice"); webView.removeJavascriptInterface("AndroidTTS"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
